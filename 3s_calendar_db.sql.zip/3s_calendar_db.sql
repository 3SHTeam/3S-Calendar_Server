-- phpMyAdmin SQL Dump
-- version 4.2.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 17-05-22 14:44
-- 서버 버전: 5.6.20
-- PHP 버전: 5.6.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 데이터베이스: `3s_calendar_db`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `friends`
--

CREATE TABLE IF NOT EXISTS `friends` (
  `Googleid` varchar(50) NOT NULL COMMENT '구글아이디',
  `Friend_Googleid` varchar(50) NOT NULL COMMENT '친구 구글아이디'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='친구관계 테이블';

-- --------------------------------------------------------

--
-- 테이블 구조 `gjoinlist`
--

CREATE TABLE IF NOT EXISTS `gjoinlist` (
  `Googleid` varchar(50) NOT NULL COMMENT '구글아이디',
  `Gid` int(11) NOT NULL COMMENT '그룹아이디'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='그룹 가입 테이블';

-- --------------------------------------------------------

--
-- 테이블 구조 `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
`Gid` int(11) NOT NULL COMMENT '그룹id',
  `Group_name` varchar(50) NOT NULL COMMENT '그룹명',
  `Group_comment` varchar(600) NOT NULL DEFAULT '저희 그룹에 가입하신것을 환영합니다' COMMENT '그룹소개',
  `GMaster` varchar(50) NOT NULL COMMENT '그룹장 구글 아이디'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='그룹 테이블';

--
-- 테이블의 덤프 데이터 `groups`
--

INSERT INTO `groups` (`Gid`, `Group_name`, `Group_comment`, `GMaster`) VALUES
(0, 'defaule', '개인 스케줄 태그 작성용 그룹', 'null');

-- --------------------------------------------------------

--
-- 테이블 구조 `invitemessages`
--

CREATE TABLE IF NOT EXISTS `invitemessages` (
`Mid` int(11) NOT NULL COMMENT '메세지 아이디',
  `sender` varchar(50) NOT NULL COMMENT '발신자ID',
  `receiver` varchar(50) NOT NULL COMMENT '수신자ID',
  `type` varchar(30) NOT NULL COMMENT '메세지타입',
  `message` varchar(500) NOT NULL COMMENT '초대메세지',
  `Gid` int(11) DEFAULT NULL COMMENT '그룹아이디'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='초대메세지';

-- --------------------------------------------------------

--
-- 테이블 구조 `schedules`
--

CREATE TABLE IF NOT EXISTS `schedules` (
`Sid` int(11) NOT NULL COMMENT '스케줄아이디',
  `SMaster` varchar(50) NOT NULL COMMENT '스케줄 생성자 구글아이디',
  `Sname` varchar(100) NOT NULL COMMENT '스케줄명',
  `Place` varchar(200) NOT NULL COMMENT '장소(구글맵url)',
  `StartTime` varchar(12) NOT NULL COMMENT '날짜/시간',
  `EndTime` varchar(12) NOT NULL COMMENT '스케줄 종료 시간'
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8 COMMENT='스케줄 테이블';

--
-- 테이블의 덤프 데이터 `schedules`
--

INSERT INTO `schedules` (`Sid`, `SMaster`, `Sname`, `Place`, `StartTime`, `EndTime`) VALUES
(103, 'zpq456@google.com', '우재가입', '한성대', '201705201830', '201705201835'),
(104, 'ieem52057@gmail.com', '가입날', '학교', '201705201915', '201705201915'),
(107, 'ieem52057@gmail.com', '이이', '이이', '201705201830', '201705202030'),
(108, 'ieem52057@gmail.com', 'naa', 'nana kk', '201705011830', '201705012030'),
(111, 'ieem52057@gmail.com', 'jkl', 'jk', '201705171658', '201705171658'),
(113, 'ieem52057@gmail.com', 'ss', 'ss', '201705181830', '201705182130'),
(114, 'ieem52057@gmail.com', 'sa', 'sa', '201705021830', '201705022030'),
(115, 'boyoon456123@gmail.com', 'ddd', 'saa', '20170502209', '20170502219'),
(121, 'ieem52057@gmail.com', 'eight', 'eight', '201705181830', '201705182029'),
(122, 'boyoon456123@gmail.com', '면담', '연구동', '20170518147', '20170518157');

-- --------------------------------------------------------

--
-- 테이블 구조 `sjoinlist`
--

CREATE TABLE IF NOT EXISTS `sjoinlist` (
  `Googleid` varchar(50) NOT NULL COMMENT '구글아이디',
  `Sid` int(11) NOT NULL COMMENT '스케줄아이디',
  `Tagid` int(11) NOT NULL COMMENT '스케줄 태그 아이디',
  `Gid` int(11) DEFAULT NULL COMMENT '그룹 아이디',
  `GoogleSid` varchar(4) NOT NULL COMMENT '구글 스케줄 아이디'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='스케줄 참여 테이블';

--
-- 테이블의 덤프 데이터 `sjoinlist`
--

INSERT INTO `sjoinlist` (`Googleid`, `Sid`, `Tagid`, `Gid`, `GoogleSid`) VALUES
('ieem52057@gmail.com', 104, 79, NULL, '1203'),
('ieem52057@gmail.com', 107, 79, NULL, '1208'),
('ieem52057@gmail.com', 108, 83, NULL, '1211'),
('ieem52057@gmail.com', 111, 79, NULL, 'even'),
('ieem52057@gmail.com', 113, 82, NULL, '1232'),
('ieem52057@gmail.com', 114, 82, NULL, '1233'),
('ieem52057@gmail.com', 121, 79, NULL, '1235'),
('zpq456@google.com', 103, 78, NULL, '246');

-- --------------------------------------------------------

--
-- 테이블 구조 `staglist`
--

CREATE TABLE IF NOT EXISTS `staglist` (
`Tagid` int(11) NOT NULL COMMENT '스케줄태그아이디',
  `Googleid` varchar(50) NOT NULL COMMENT '구글아이디',
  `Tag_name` varchar(60) NOT NULL COMMENT '스케줄태그명',
  `Color` varchar(9) NOT NULL COMMENT '색상',
  `Font` varchar(20) NOT NULL DEFAULT '맑은고딕' COMMENT '글꼴',
  `Size` varchar(5) NOT NULL DEFAULT '15' COMMENT '글씨크기',
  `Gid` int(11) DEFAULT NULL COMMENT '그룹 아이디'
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8 COMMENT='스케줄 태그 테이블';

--
-- 테이블의 덤프 데이터 `staglist`
--

INSERT INTO `staglist` (`Tagid`, `Googleid`, `Tag_name`, `Color`, `Font`, `Size`, `Gid`) VALUES
(78, 'zpq456@google.com', 'zpq456@google.com', '#82B926', '맑은고딕', '15', NULL),
(79, 'ieem52057@gmail.com', 'ieem52057@gmail.com', '#82B926', '맑은고딕', '15', NULL),
(80, 'boyoon456123@gmail.com', 'boyoon456123@gmail.com', '#82B926', '맑은고딕', '15', NULL),
(82, 'ieem52057@gmail.com', '화이팅', '#FFE3EE', '맑은고딕', '15', NULL),
(83, 'ieem52057@gmail.com', 'to do', '#C0FFFF', '맑은고딕', '15', NULL),
(84, 'boyoon456123@gmail.com', 'aaaaa', '#ff66cc', '맑은고딕', '15', NULL);

-- --------------------------------------------------------

--
-- 테이블 구조 `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `Googleid` varchar(50) NOT NULL DEFAULT '' COMMENT '구글아이디',
  `Googlepw` varchar(50) NOT NULL COMMENT '구글 비밀번호',
  `name` varchar(15) NOT NULL COMMENT '이름',
  `gender` char(1) NOT NULL COMMENT '성별 M/W',
  `nickname` varchar(30) NOT NULL COMMENT '별명',
  `birth` varchar(6) NOT NULL COMMENT '생일(주민번호앞자리)',
  `phone` varchar(12) NOT NULL COMMENT '연락처',
  `comment` varchar(600) NOT NULL DEFAULT '반갑습니다. 잘부탁드려요' COMMENT '한마디',
  `FBuId` varchar(200) NOT NULL COMMENT '파이어베이스 키값',
  `FBToken` varchar(500) NOT NULL COMMENT '기기등록 토큰'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='유저관리를 위한 테이블';

--
-- 테이블의 덤프 데이터 `users`
--

INSERT INTO `users` (`Googleid`, `Googlepw`, `name`, `gender`, `nickname`, `birth`, `phone`, `comment`, `FBuId`, `FBToken`) VALUES
('boyoon456123@gmail.com', '111111', '최보윤', 'W', 'jwndn', '940410', '01066311668', 'hello', 'null', 'fBOdouk6q8U:APA91bFrocJ-qGYwEwl_zYrxymXbZXs8rSUN62g9rT-rbEG6CInD29W8Nxti-9FMflhvcNjPOodRy9HeX5_6UeizYBYhXR_okPxzFc_UPk3VhWCio1mcvDS1If4vtJ27ETYMRn5x-fVR'),
('ieem52057@gmail.com', '111111', '이임경', 'W', '기린영양', '930303', '01063843571', 'hi', 'null', 'didrjTs1Dm8:APA91bHW5c3vYE0OJ3SlVXTRFL6fykYhh-A9Syq1K6gBAwfSWk3OhPaKNdBYTaA4eCUjxiCszQH99B3bJAoMJdOqPsdj5MRY_rcz4Q_zS8BNPrlchNP4_L5gjrGQAOgXJzp_MPrXUScy'),
('zpq456@google.com', '111111', '유우재', 'M', '우재', '930501', '01051138561', '하이', 'null', 'd_aZozyrb78:APA91bHC-7Evsxypw5TnBY47paK23dvIGwfuvdrfG6syOvJXKQFVVfJU4-54Uu-CNOGzmYtMNK30fqlkKDp3gtrEb-CjAPkGuNeoxOrf1apHuFcPwMB1ylBqatM_0_-WJSMBsS3ASxR6');

--
-- 덤프된 테이블의 인덱스
--

--
-- 테이블의 인덱스 `friends`
--
ALTER TABLE `friends`
 ADD PRIMARY KEY (`Googleid`,`Friend_Googleid`), ADD KEY `Friend_Googleid` (`Friend_Googleid`);

--
-- 테이블의 인덱스 `gjoinlist`
--
ALTER TABLE `gjoinlist`
 ADD PRIMARY KEY (`Googleid`,`Gid`), ADD KEY `Gid` (`Gid`);

--
-- 테이블의 인덱스 `groups`
--
ALTER TABLE `groups`
 ADD PRIMARY KEY (`Gid`), ADD UNIQUE KEY `Gid` (`Gid`);

--
-- 테이블의 인덱스 `invitemessages`
--
ALTER TABLE `invitemessages`
 ADD PRIMARY KEY (`Mid`);

--
-- 테이블의 인덱스 `schedules`
--
ALTER TABLE `schedules`
 ADD PRIMARY KEY (`Sid`), ADD KEY `SMaster` (`SMaster`);

--
-- 테이블의 인덱스 `sjoinlist`
--
ALTER TABLE `sjoinlist`
 ADD PRIMARY KEY (`Googleid`,`Sid`,`Tagid`), ADD KEY `Sid` (`Sid`), ADD KEY `Tagid` (`Tagid`);

--
-- 테이블의 인덱스 `staglist`
--
ALTER TABLE `staglist`
 ADD PRIMARY KEY (`Tagid`), ADD KEY `Googleid` (`Googleid`), ADD KEY `Gid` (`Gid`);

--
-- 테이블의 인덱스 `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`Googleid`);

--
-- 덤프된 테이블의 AUTO_INCREMENT
--

--
-- 테이블의 AUTO_INCREMENT `groups`
--
ALTER TABLE `groups`
MODIFY `Gid` int(11) NOT NULL AUTO_INCREMENT COMMENT '그룹id';
--
-- 테이블의 AUTO_INCREMENT `invitemessages`
--
ALTER TABLE `invitemessages`
MODIFY `Mid` int(11) NOT NULL AUTO_INCREMENT COMMENT '메세지 아이디';
--
-- 테이블의 AUTO_INCREMENT `schedules`
--
ALTER TABLE `schedules`
MODIFY `Sid` int(11) NOT NULL AUTO_INCREMENT COMMENT '스케줄아이디',AUTO_INCREMENT=123;
--
-- 테이블의 AUTO_INCREMENT `staglist`
--
ALTER TABLE `staglist`
MODIFY `Tagid` int(11) NOT NULL AUTO_INCREMENT COMMENT '스케줄태그아이디',AUTO_INCREMENT=85;
--
-- 덤프된 테이블의 제약사항
--

--
-- 테이블의 제약사항 `friends`
--
ALTER TABLE `friends`
ADD CONSTRAINT `friends_ibfk_1` FOREIGN KEY (`Googleid`) REFERENCES `users` (`Googleid`),
ADD CONSTRAINT `friends_ibfk_2` FOREIGN KEY (`Friend_Googleid`) REFERENCES `users` (`Googleid`);

--
-- 테이블의 제약사항 `gjoinlist`
--
ALTER TABLE `gjoinlist`
ADD CONSTRAINT `gjoinlist_ibfk_1` FOREIGN KEY (`Googleid`) REFERENCES `users` (`Googleid`),
ADD CONSTRAINT `gjoinlist_ibfk_2` FOREIGN KEY (`Gid`) REFERENCES `groups` (`Gid`);

--
-- 테이블의 제약사항 `sjoinlist`
--
ALTER TABLE `sjoinlist`
ADD CONSTRAINT `sjoinlist_ibfk_1` FOREIGN KEY (`Googleid`) REFERENCES `users` (`Googleid`),
ADD CONSTRAINT `sjoinlist_ibfk_2` FOREIGN KEY (`Sid`) REFERENCES `schedules` (`Sid`),
ADD CONSTRAINT `sjoinlist_ibfk_3` FOREIGN KEY (`Tagid`) REFERENCES `staglist` (`Tagid`);

--
-- 테이블의 제약사항 `staglist`
--
ALTER TABLE `staglist`
ADD CONSTRAINT `staglist_ibfk_1` FOREIGN KEY (`Googleid`) REFERENCES `users` (`Googleid`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
